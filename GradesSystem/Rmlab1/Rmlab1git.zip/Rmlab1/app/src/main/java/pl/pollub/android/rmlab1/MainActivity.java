package pl.pollub.android.rmlab1;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    boolean imieCorr = false;
    boolean nazwCorr = false;
    boolean liczbCorr = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.lab12);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        EditText imieEdit = findViewById(R.id.editTextImie);
        imieEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    if (imieEdit.getText().toString().isEmpty())
                    {
                        Toast.makeText(MainActivity.this,
                                        "Imie nie moze byc puste",
                                        Toast.LENGTH_SHORT)
                                .show();
                        imieEdit.setError("Pole nie moze byc puste");
                        imieCorr = false;
                    }
                    else {
                        imieCorr = true;
                        MainActivity.this.checkData();
                    }
                }
            }
        });

        EditText nazwEdit = findViewById(R.id.editTextNazwisko);
        nazwEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b) {
                    if (nazwEdit.getText().toString().isEmpty())
                    {
                        Toast.makeText(MainActivity.this,
                                        "Nazwisko nie moze byc puste",
                                        Toast.LENGTH_SHORT)
                                .show();
                        nazwEdit.setError("Pole nie moze byc puste");
                        nazwCorr = false;
                    }
                    else {
                        nazwCorr = true;
                        MainActivity.this.checkData();
                    }
                }

            }
        });

        EditText liczbaEdit = findViewById(R.id.editTextLiczbaocen);
        liczbaEdit.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean b) {
                if (!b)
                {
                    int val;
                    try
                    {
                        val = Integer.parseInt(liczbaEdit.getText().toString());
                    }
                    catch (Exception e) {
                        Toast.makeText(MainActivity.this,
                                        "Nieprawidlowa wartosc",
                                        Toast.LENGTH_SHORT)
                                .show();
                        liczbaEdit.setError("Nieprawidlowa wartosc");
                        liczbCorr = false;
                        return;
                    }
                    if (val < 5 || val > 15) {
                        Toast.makeText(MainActivity.this,
                                        "Liczba ocen musi byc w przedziale 5-15",
                                        Toast.LENGTH_SHORT)
                                .show();
                        liczbaEdit.setError("Nieprawidlowy przedzial");
                        liczbCorr = false;
                    }
                    else {
                        liczbCorr = true;
                         MainActivity.this.checkData();
                    }
                }

            }
        });
    }

    protected void checkData() {
        if (imieCorr && nazwCorr && liczbCorr) {
            Button oceny = findViewById(R.id.oceny_button);
            oceny.setVisibility(View.VISIBLE);
            Toast.makeText(MainActivity.this,
                            "Ale super!",
                            Toast.LENGTH_SHORT)
                    .show();
        }
    }


}